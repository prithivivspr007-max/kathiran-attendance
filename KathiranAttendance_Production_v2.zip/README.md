# Kathiran Attendance — Production Firebase Android App

One Android app for ADMIN, A+, A and EMPLOYEE roles, using the Kathiran Attendance Firebase project.

## Important
This is a production-source project, not the old localStorage demo. Firestore is configured with IndexedDB local cache for offline reads/queued writes, and Storage is used for employee/Aadhaar uploads.

## Build APK on GitHub
1. Put the project files in the root of a GitHub repository.
2. Open **Actions**.
3. Select **Build Kathiran Attendance APK**.
4. Tap **Run workflow**.
5. Open the completed workflow.
6. Under **Artifacts**, download `kathiran-attendance-debug-apk`.
7. Extract the artifact and install `app-debug.apk` on Android.

## Firebase setup
Enable Authentication (Email/Password), Firestore and Storage in project `kathiran-attendance`, deploy `firestore.rules` and `storage.rules`, and create the first ADMIN account securely. Do not add production passwords to source code.

## Roles
- ADMIN: full authority.
- A+: same operational authority; `salaried` can be true or false.
- A: manager/attendance role; can view/calculate/print salary but cannot edit payroll.
- EMPLOYEE: own data only; login is optional for employee records.

## Category colours
ADMIN = white, A+ = blue, A = yellow, EMPLOYEE = green.


## Version 1.0.1 fixes
- Uses the current Firebase Android project API key from google-services.json.
- Fixes the bundled logo path for Android WebView (logo.png instead of assets/logo.png).
- VersionCode 2 / VersionName 1.0.1.
