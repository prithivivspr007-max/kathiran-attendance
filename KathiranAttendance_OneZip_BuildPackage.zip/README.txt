KATHIRAN ATTENDANCE - ONE ZIP BUILD

This package lets you keep the Android project as a ZIP in GitHub. GitHub does not extract ZIP files automatically, so the included workflow must itself be placed at .github/workflows/build-from-zip.yml in the repository.

After the workflow file is present and project ZIP is uploaded:
GitHub -> Actions -> Build Kathiran Attendance APK from ZIP -> Run workflow.

IMPORTANT: Uploading this outer ZIP alone will NOT make GitHub recognize the workflow because GitHub never extracts uploaded ZIP archives. The workflow file must be uploaded as a real file in .github/workflows/.
